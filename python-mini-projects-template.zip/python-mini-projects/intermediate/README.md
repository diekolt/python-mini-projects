# Intermediate Projects
Projects involving file handling, GUIs, and APIs.