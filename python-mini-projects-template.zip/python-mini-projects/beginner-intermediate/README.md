# Beginner-Intermediate Projects
Small games and logic-based projects.