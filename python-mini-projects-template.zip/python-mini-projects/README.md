# Python Mini Projects

This repository contains my Python learning journey through progressively harder mini-projects.

## Structure
- beginner/
- beginner-intermediate/
- intermediate/
- advanced/
- expert/
- checklist/
