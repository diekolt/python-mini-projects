# Beginner Projects
Basic Python exercises to practice syntax, loops, and conditionals.